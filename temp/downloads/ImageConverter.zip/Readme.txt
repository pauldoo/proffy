Run the .jar file and you'll get a little file selection box opening up.

Just select all the jpeg files you want to generate an index for and it'll 
create a new dir inside the same folder with all the junk you need.

It makes the thumbnails fit inside 160x160 (preserving aspect), and makes the 
full sized images fit inside 1024x1024 (again preserving aspect).

You can change those sizes by editing ImageConverter.properties.

The only way you know when the program has finished is when the command window 
disappears.  It doesn't take long anyway tho..

I used it to generate the indexes at http://www.minioak.com/~pauldoo/.  It's 
not brilliant but it does the job.


-- 
Paul Richards
p.a.richards@sms.ed.ac.uk
